/**************************************************************************
Filename : CUSBDlg.cpp
Language : Cpp
Description : implementation file.
Author(s) :   
Company  : ANCH Ltd.
version  : 1.0
Change Log : 2007-3-3
******************************************************************************/


#include "stdafx.h"
#include "CUSB.h"
#include "CUSBDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define BulkIoPhase_In			0x80
#define BulkIoPhase_Out 		0x00
#define	BulkIoPhase_Idle		0xff
#define BulkIoSignature			0x43425355
#define BULK_IO_ACK					0x53425355


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCUSBDlg dialog

CCUSBDlg::CCUSBDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCUSBDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCUSBDlg)
	m_Context = _T("");
	m_ContextSend = _T("");
	m_Length = _T("");
	m_RecLen = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCUSBDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCUSBDlg)
	DDX_Text(pDX, IDC_EDIT, m_Context);
	DDX_Text(pDX, IDC_EDIT_SENT, m_ContextSend);
	DDX_Text(pDX, IDC_STATIC_Length, m_Length);
	DDX_Text(pDX, IDC_REC_LENGTH, m_RecLen);
	DDV_MaxChars(pDX, m_RecLen, 512);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCUSBDlg, CDialog)
	//{{AFX_MSG_MAP(CCUSBDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnButtonConnect)
	ON_BN_CLICKED(ID_SEND_OK, OnSendOk)
	ON_BN_CLICKED(IDC_TEST, OnTest)
	ON_EN_CHANGE(IDC_EDIT_SENT, OnChangeEditSent)
	ON_BN_CLICKED(IDC_BUTTON_EXIT, OnButtonExit)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_EN_CHANGE(IDC_EDIT, OnChangeEdit)
	ON_EN_CHANGE(IDC_REC_LENGTH, OnChangeRecLength)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCUSBDlg message handlers

BOOL CCUSBDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_Length = "0";
	m_RecLen = "512";
	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control

}

void CCUSBDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCUSBDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCUSBDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCUSBDlg::OnButtonConnect() 
{
	// TODO: Add your control notification handler code here
	if (ERROR_SUCCESS != mydevice.IniDevice())
	{
		CString error;
		error.Format("Device Invalid!!!��Error Num(%d)", GetLastError());
		AfxMessageBox(error);
	}
	else
	{
		AfxMessageBox("Device Connect Successfully!");
	}

}


void CCUSBDlg::OnSendOk() 
{
	DWORD	dError = 0;
	UINT	SendLength;
	UINT	outputLength;
	UpdateData(TRUE);
	SendLength = m_ContextSend.GetLength();
	BYTE BulkIoRequest[8]={
				0x55,
				0x53,
				0x42,
				0x43,	//IoRequestSignature

				BulkIoPhase_Out,	

				0x00,	//Length	LSB
				0x02,
				0x00	//			MSB
	};
	BulkIoRequest[5]=SendLength;
	BulkIoRequest[6]=SendLength>>8;	

	BYTE BulkIoAck[4];
	ReadEditToBuffer();
	outputLength = 0;
	mydevice.Endpoint1WritePipes(0x8,BulkIoRequest,&outputLength);
	if(SendLength != 0)	//avoid 0 length pkt send
	{
		outputLength = 0;
		if(ERROR_SUCCESS != mydevice.Endpoint1WritePipes(SendLength,bBuffer,&outputLength))
		{
			CString error;
			error.Format("д���󣬴����(%d)������ԣ�", dError);
			AfxMessageBox(error);
		}
	}

	outputLength = 0;
	if(ERROR_SUCCESS !=mydevice.Endpoint1ReadPipes(0x4,BulkIoAck,&outputLength))
	{
		CString error;
		error.Format("ACK��������ԣ�");
		AfxMessageBox(error);
	}
}

//DEL void CCUSBDlg::OnButtonRecieve() 
//DEL {
//DEL 	// TODO: Add your control notification handler code here
//DEL 	if(ERROR_SUCCESS != mydevice.Endpoint1ReadPipes(512,bBuffer))
//DEL 	{
//DEL 		CString error;
//DEL 		error.Format("����������ԣ�");
//DEL 		AfxMessageBox(error);
//DEL 	}
//DEL 	else
//DEL 	{
//DEL 		CString error;
//DEL 		error.Format("����ȷ(%d)", *(bBuffer+255));
//DEL 		AfxMessageBox(error);
//DEL 	}
//DEL }

void CCUSBDlg::OnTest() 
{
	UINT	ReceiveLength = 0;
	UINT	TextLength;
	UINT		i;
	UINT	outputLength;

	UpdateData(TRUE);
	TextLength = m_RecLen.GetLength();
	for(i=0;i<TextLength;i++)
	{
		ReceiveLength = ReceiveLength * 10;
		ReceiveLength += Char2Num(m_RecLen.GetAt(i));
	}
	
//	ReceiveLength = m_ContextSend.GetLength()/2;
	BYTE BulkIoRequest[8]={
				0x55,
				0x53,
				0x42,
				0x43,	//IoRequestSignature

				BulkIoPhase_In,	

				0x00,	//Length	LSB
				0x00,
				0x00	//			MSB
	};
	BYTE BulkIoAck[4];
	BulkIoRequest[5]=ReceiveLength;
	BulkIoRequest[6]=ReceiveLength>>8;

	outputLength = 0;
	mydevice.Endpoint1WritePipes(0x8,BulkIoRequest,&outputLength);
	if(ReceiveLength != 0)
	{
		outputLength=0;
		if(ERROR_SUCCESS != mydevice.Endpoint1ReadPipes(ReceiveLength,bReceiveBuffer,&outputLength))
		{
			CString error;
			error.Format("����������ԣ�");
			AfxMessageBox(error);
		}
	}
	outputLength=0;
	if(ERROR_SUCCESS !=mydevice.Endpoint1ReadPipes(0x4,BulkIoAck,&outputLength))
	{
		CString error;
		error.Format("ACK��������ԣ�");
		AfxMessageBox(error);
	}
	m_Context = "";
	ShowReceivedData(ReceiveLength);
	UpdateData(FALSE); //���±༭������	
}

void CCUSBDlg::ShowReceivedData(UINT ReceiveLength)
{
	unsigned int i;
	for(i=0;i<ReceiveLength;i++)
	{
		CCUSBDlg::Show_Byte_HEX(m_Context,bReceiveBuffer[i]);
	}
}

void CCUSBDlg::Show_Byte_HEX(CString &tempstring, BYTE data_byte)
{
	CString strtemp;
	BYTE char_2_Hex;
	char_2_Hex=data_byte>>4;
	if (char_2_Hex>9){
		char_2_Hex=char_2_Hex+'A'-10;
				}
	else char_2_Hex=char_2_Hex+'0';
	strtemp.Format("%c",char_2_Hex);
	tempstring+=strtemp;
	char_2_Hex=data_byte%16;
	if (char_2_Hex>9){
		char_2_Hex=char_2_Hex+'A'-10;
				}
	else char_2_Hex=char_2_Hex+'0';
	strtemp.Format("%c",char_2_Hex);
//	tempstring+=strtemp;
//	strtemp.Format("%c",' ');// add a space
	tempstring+=strtemp;
    
}

void CCUSBDlg::ReadEditToBuffer()
{
	UINT TxLength;
	BYTE temp;
	UINT i;
	UpdateData(TRUE);
	TxLength = m_ContextSend.GetLength();
	if(TxLength >512)
	{
		CString error;
		error.Format("���԰淢�ͳ������512 Byte");
		AfxMessageBox(error);
	}
	else if((m_ContextSend.GetLength())&0x1)
	{
		CString error;
		error.Format("����������󣬱�����ż����");
		AfxMessageBox(error);
	}
	for(i=0;i<TxLength;i++)
	{
//		temp=m_ContextSend.GetAt(i*2);
//		temp=Char2Num(temp);
//		bBuffer[i] = temp<<4;
//		temp=m_ContextSend.GetAt(i*2+1);
//		temp=Char2Num(temp);
//		bBuffer[i]+=temp;

		temp=m_ContextSend.GetAt(i);
		bBuffer[i] = temp;
	}
}

BYTE CCUSBDlg::Char2Num(unsigned char asc)
{
	if(asc>='0'&&asc<='9')
		return (asc-'0');
	else if(asc>='a'&&asc<='f')
		return (asc-'a'+10);
	else if(asc>='A'&&asc<='F')
		return (asc-'A'+10);
	else
		return -1;

}

void CCUSBDlg::OnChangeEditSent() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	UINT TxLength = m_ContextSend.GetLength()/2;;
	m_Length.Format("%d",TxLength);
	UpdateData(FALSE);
}

void CCUSBDlg::OnButtonExit() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
	
}

void CCUSBDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UINT	ReceiveLength = 0;
	UINT	TextLength;
	UINT		i;
	UINT	outputLength;
	BYTE BulkIoAck[4];

	UpdateData(TRUE);

	TextLength = m_RecLen.GetLength();
	for(i=0;i<TextLength;i++)
	{
		ReceiveLength = ReceiveLength * 10;
		ReceiveLength += Char2Num(m_RecLen.GetAt(i));
	}
	
	BYTE BulkIoRequest[9]={
				0xa1,
				0x00,
				0x06,
				0x00,
				0xb0,
				0x00,
				0x00,	//Length	LSB
				0x00,   //Length    MSB
				0xff	//			
	};

	BulkIoRequest[6]=ReceiveLength;
	BulkIoRequest[7]=ReceiveLength>>8;

    outputLength = 0;
	mydevice.Endpoint1WritePipes(0x9,BulkIoRequest,&outputLength);

	if(ReceiveLength != 0)
	{
	   outputLength = 0;
	   if(ERROR_SUCCESS !=mydevice.Endpoint1ReadPipes(ReceiveLength,bReceiveBuffer,&outputLength))
	   {
		  CString error;
		  error.Format("ACK��������ԣ�");
		  AfxMessageBox(error);
	   }
	}

	/*if(0==(ReceiveLength%64))	
	{
       outputLength=0;
	   if(ERROR_SUCCESS !=mydevice.Endpoint1ReadPipes(0,BulkIoAck,&outputLength))
	   {
		  CString error;
		  error.Format("ACK��������ԣ�");
		  AfxMessageBox(error);
	   }
	}*/
	ShowReceivedData(ReceiveLength);

	UpdateData(FALSE); //���±༭������
}

void CCUSBDlg::OnChangeEdit() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}

void CCUSBDlg::OnChangeRecLength() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	
}
