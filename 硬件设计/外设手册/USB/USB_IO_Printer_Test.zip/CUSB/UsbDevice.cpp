/**************************************************************************
Filename : UsbDevice.cpp
Language : Cpp
Description : implementation of the CUsbDevice class.
Author(s) :   
Company  : AisinoChip Ltd.
version  : 1.0
Change Log : 2007-3-3
******************************************************************************/


#include "stdafx.h"
#include "UsbDevice.h"
#include "intrface.h"
#include <winioctl.h>
#include <initguid.h>

#define AISNCUSB_GUID \
	{ 0xAB8AF19D, 0xF042, 0x4A5C, { 0xBE, 0xD3, 0x82, 0x49, 0x10, 0x97, 0x65, 0x4B } }
	
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

HANDLE OpenByInterface(GUID* pClassGuid, DWORD instance, PDWORD pError);
GUID ClassGuid = AISNCUSB_GUID;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUsbDevice::CUsbDevice()
{

}

CUsbDevice::~CUsbDevice()
{

}

DWORD CUsbDevice::IniDevice(DWORD instance)
{
	DWORD	dError = 0;
	hDevice = OpenByInterface( &ClassGuid, instance, &dError);
	if (hDevice == INVALID_HANDLE_VALUE)
	{
		return dError;
	}

	return ERROR_SUCCESS;
}

DWORD CUsbDevice::CloseDevice()
{
	if (!CloseHandle(hDevice))
	{
		return GetLastError();
	}
	else
	{
		return ERROR_SUCCESS;
	}
}


DWORD CUsbDevice::Endpoint1WritePipes(UINT Length,void* pBuffer,UINT *nBytesWritten)
{
	DWORD	nOutput;	
	DWORD	error;
	if (!DeviceIoControl(hDevice,
						 IOCTL_AISNCUSB_BULK_OUT,
						 pBuffer,
						 Length,
						 NULL,
						 0,
						 &nOutput,
						 NULL)){	
		error = GetLastError();
		return(error);
	}

	*nBytesWritten = nOutput;

	return ERROR_SUCCESS;
}


DWORD CUsbDevice::Endpoint1ReadPipes(UINT Length,void* pBuffer,UINT *nBytesRead)
{
	ULONG	nOutput;
	DWORD	error;

	if (!DeviceIoControl(hDevice,
						 IOCTL_AISNCUSB_BULK_IN,
						 NULL,
						 0,
						 pBuffer,
						 Length,
						 &nOutput,
						 NULL)){	
		error = GetLastError();
		return(error);
	}

	*nBytesRead = nOutput;

	return ERROR_SUCCESS;
}

DWORD CUsbDevice::ResetDevice()
{
	DWORD	error;
	ULONG	nOutput;

	if (!DeviceIoControl(hDevice,
						 IOCTL_AISNCUSB_RESET_DEVICE,
						 NULL,
						 0,
						 NULL,
						 0,
						 &nOutput,
						 NULL)){	
		error = GetLastError();
		return(error);
	}

	return ERROR_SUCCESS;
}