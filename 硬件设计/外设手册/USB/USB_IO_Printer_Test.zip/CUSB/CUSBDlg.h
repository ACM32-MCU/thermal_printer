// CUSBDlg.h : header file
//

#if !defined(AFX_CUSBDLG_H__D07A1FAD_5099_41A2_B43A_17FC7644CCD3__INCLUDED_)
#define AFX_CUSBDLG_H__D07A1FAD_5099_41A2_B43A_17FC7644CCD3__INCLUDED_

#include "UsbDevice.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCUSBDlg dialog

class CCUSBDlg : public CDialog
{
// Construction
public:
	BYTE Char2Num(unsigned char asc);
	void ReadEditToBuffer();
	void Show_Byte_HEX(CString &tempstring,BYTE data_byte);
	void ShowReceivedData(UINT ReceiveLength);
	CUsbDevice mydevice;
	CCUSBDlg(CWnd* pParent = NULL);	// standard constructor
	BYTE bBuffer[512];
	BYTE bReceiveBuffer[512];

// Dialog Data
	//{{AFX_DATA(CCUSBDlg)
	enum { IDD = IDD_CUSB_DIALOG };
	CString	m_Context;
	CString	m_ContextSend;
	CString	m_Length;
	CString	m_RecLen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCUSBDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCUSBDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonConnect();
	afx_msg void OnSendOk();
	afx_msg void OnTest();
	afx_msg void OnChangeEditSent();
	afx_msg void OnButtonExit();
	afx_msg void OnButton1();
	afx_msg void OnChangeEdit();
	afx_msg void OnChangeRecLength();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CUSBDLG_H__D07A1FAD_5099_41A2_B43A_17FC7644CCD3__INCLUDED_)
