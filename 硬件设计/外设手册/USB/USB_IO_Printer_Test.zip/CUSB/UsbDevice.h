// UsbDevice.h: interface for the CUsbDevice class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USBDEVICE_H__EF977808_91B8_4C1D_A72B_47470B327FFC__INCLUDED_)
#define AFX_USBDEVICE_H__EF977808_91B8_4C1D_A72B_47470B327FFC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUsbDevice  
{
public:
	CUsbDevice();

	virtual ~CUsbDevice();

	DWORD IniDevice(DWORD instance = 0);

	DWORD CloseDevice();

	DWORD Endpoint1ReadPipes(UINT Length,void* pBuffer,UINT *nBytesRead);

	DWORD Endpoint1WritePipes(UINT Length,void* pBuffer,UINT *nBytesWritten);

	DWORD ResetDevice();
	
protected:
	HANDLE hDevice;
};

#endif // !defined(AFX_USBDEVICE_H__EF977808_91B8_4C1D_A72B_47470B327FFC__INCLUDED_)
